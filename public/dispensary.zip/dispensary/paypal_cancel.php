<!DOCTYPE html>
<html>
<head>
	<title>Payment UnSuccessful</title>
</head>
<body>
<h1>Welcome <?php echo $_SESSION['customer_email']; ?></h1>
<h2>Your Payment was cancelled, please go to our shop</h2>
<h3><a href="localhost/482/482Main/home.php">Go to home page</a></h3>
</body>
</html>