<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		#footer{
	width:1400px;
	height: 150px;
	background: black;
	clear: both;
	text-align: center;
}
	</style>
</head>
<body>
<h1><font color="white">Copyright &copy; W3Schools.com</font></h1> <br>

</body>
</html>