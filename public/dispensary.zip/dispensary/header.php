<!DOCTYPE html>
<html>
<head>
	<title></title>
	
	<style type="text/css">
		.header_wrapper{
width:1400px;
height: 150px;
margin: auto;
}
#logo{float: left;}
#banner{float: right;}

	</style>

</head>
<body>
<img id="logo" src="images/mainlogo.jpg" height="150" width="690" class="responsive">
	<img id="banner" src="images/ad_banner.gif" height="150" width="710" class="responsive">
</body>
</html>